#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DATA_FILE "students.dat"
#define TEMP_FILE "temp.dat"

struct Student {
    int roll;
    char name[50];
    char course[30];
    float marks;
};

void clearInput(void) {
    int ch;
    while ((ch = getchar()) != '\n' && ch != EOF) {
    }
}

int readInteger(const char *message) {
    char line[100];
    int value;
    char extra;

    while (1) {
        printf("%s", message);
        if (fgets(line, sizeof(line), stdin) == NULL) {
            return 0;
        }
        if (sscanf(line, "%d %c", &value, &extra) == 1) {
            return value;
        }
        printf("Please enter a valid whole number.\n");
    }
}

float readMarks(const char *message) {
    char line[100];
    float value;
    char extra;

    while (1) {
        printf("%s", message);
        if (fgets(line, sizeof(line), stdin) == NULL) {
            return 0.0f;
        }
        if (sscanf(line, "%f %c", &value, &extra) == 1 &&
            value >= 0.0f && value <= 100.0f) {
            return value;
        }
        printf("Please enter marks between 0 and 100.\n");
    }
}

void readText(const char *message, char *text, int size) {
    printf("%s", message);
    if (fgets(text, size, stdin) != NULL) {
        text[strcspn(text, "\n")] = '\0';
    }
}

int rollExists(int roll) {
    FILE *file = fopen(DATA_FILE, "rb");
    struct Student student;

    if (file == NULL) {
        return 0;
    }

    while (fread(&student, sizeof(student), 1, file) == 1) {
        if (student.roll == roll) {
            fclose(file);
            return 1;
        }
    }

    fclose(file);
    return 0;
}

void addStudent(void) {
    FILE *file;
    struct Student student;

    printf("\n--- Add Student ---\n");
    student.roll = readInteger("Enter roll number: ");

    if (rollExists(student.roll)) {
        printf("This roll number already exists.\n");
        return;
    }

    readText("Enter student name: ", student.name, sizeof(student.name));
    readText("Enter course name: ", student.course, sizeof(student.course));
    student.marks = readMarks("Enter marks (0-100): ");

    file = fopen(DATA_FILE, "ab");
    if (file == NULL) {
        printf("Unable to open the data file.\n");
        return;
    }

    if (fwrite(&student, sizeof(student), 1, file) == 1) {
        printf("Student record saved successfully.\n");
    } else {
        printf("Could not save the record.\n");
    }

    fclose(file);
}

void displayStudents(void) {
    FILE *file = fopen(DATA_FILE, "rb");
    struct Student student;
    int count = 0;

    printf("\n--- All Student Records ---\n");

    if (file == NULL) {
        printf("No records found yet.\n");
        return;
    }

    printf("%-10s %-25s %-20s %-10s\n",
           "Roll No.", "Name", "Course", "Marks");
    printf("-------------------------------------------------------------------\n");

    while (fread(&student, sizeof(student), 1, file) == 1) {
        printf("%-10d %-25s %-20s %-10.2f\n",
               student.roll, student.name, student.course, student.marks);
        count++;
    }

    if (count == 0) {
        printf("No records found yet.\n");
    }

    fclose(file);
}

void searchStudent(void) {
    FILE *file = fopen(DATA_FILE, "rb");
    struct Student student;
    int roll;
    int found = 0;

    printf("\n--- Search Student ---\n");
    roll = readInteger("Enter roll number to search: ");

    if (file == NULL) {
        printf("No records found yet.\n");
        return;
    }

    while (fread(&student, sizeof(student), 1, file) == 1) {
        if (student.roll == roll) {
            printf("Record found:\n");
            printf("Roll Number: %d\n", student.roll);
            printf("Name: %s\n", student.name);
            printf("Course: %s\n", student.course);
            printf("Marks: %.2f\n", student.marks);
            found = 1;
            break;
        }
    }

    if (!found) {
        printf("Student record not found.\n");
    }

    fclose(file);
}

void updateStudent(void) {
    FILE *file = fopen(DATA_FILE, "rb");
    FILE *temp;
    struct Student student;
    int roll;
    int found = 0;

    printf("\n--- Update Student ---\n");
    roll = readInteger("Enter roll number to update: ");

    if (file == NULL) {
        printf("No records found yet.\n");
        return;
    }

    temp = fopen(TEMP_FILE, "wb");
    if (temp == NULL) {
        printf("Unable to create temporary file.\n");
        fclose(file);
        return;
    }

    while (fread(&student, sizeof(student), 1, file) == 1) {
        if (student.roll == roll) {
            printf("Enter the new details.\n");
            readText("New student name: ", student.name, sizeof(student.name));
            readText("New course name: ", student.course, sizeof(student.course));
            student.marks = readMarks("New marks (0-100): ");
            found = 1;
        }
        fwrite(&student, sizeof(student), 1, temp);
    }

    fclose(file);
    fclose(temp);

    remove(DATA_FILE);
    rename(TEMP_FILE, DATA_FILE);

    if (found) {
        printf("Student record updated successfully.\n");
    } else {
        printf("Student record not found.\n");
    }
}

void deleteStudent(void) {
    FILE *file = fopen(DATA_FILE, "rb");
    FILE *temp;
    struct Student student;
    int roll;
    int found = 0;

    printf("\n--- Delete Student ---\n");
    roll = readInteger("Enter roll number to delete: ");

    if (file == NULL) {
        printf("No records found yet.\n");
        return;
    }

    temp = fopen(TEMP_FILE, "wb");
    if (temp == NULL) {
        printf("Unable to create temporary file.\n");
        fclose(file);
        return;
    }

    while (fread(&student, sizeof(student), 1, file) == 1) {
        if (student.roll == roll) {
            found = 1;
        } else {
            fwrite(&student, sizeof(student), 1, temp);
        }
    }

    fclose(file);
    fclose(temp);

    remove(DATA_FILE);
    rename(TEMP_FILE, DATA_FILE);

    if (found) {
        printf("Student record deleted successfully.\n");
    } else {
        printf("Student record not found.\n");
    }
}

int main(void) {
    int choice;

    do {
        printf("\n====================================\n");
        printf("   STUDENT RECORD MANAGEMENT SYSTEM\n");
        printf("====================================\n");
        printf("1. Add Student\n");
        printf("2. Display All Students\n");
        printf("3. Search Student\n");
        printf("4. Update Student\n");
        printf("5. Delete Student\n");
        printf("0. Exit\n");

        choice = readInteger("Enter your choice: ");

        switch (choice) {
            case 1:
                addStudent();
                break;
            case 2:
                displayStudents();
                break;
            case 3:
                searchStudent();
                break;
            case 4:
                updateStudent();
                break;
            case 5:
                deleteStudent();
                break;
            case 0:
                printf("Thank you for using the program.\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 0);

    return 0;
}
