# Student Record Management System (C)

## Project description
A menu-driven C project to store and manage student records. It supports adding,
displaying, searching, updating, and deleting records. Records are saved in a
local binary file named `students.dat`, so they remain available after the
program is closed.

## Requirements
- A C compiler such as GCC
- Windows, Linux, or macOS

## Compile and run
Open a terminal in this project folder and run:

```bash
gcc student_record.c -o student_record
```

On Windows:
```bash
student_record.exe
```

On Linux/macOS:
```bash
./student_record
```

The `students.dat` file is created automatically when the first student is added.
Keep this file in the same folder as the program when you want to retain records.

## Menu features
1. Add Student — saves roll number, name, course, and marks.
2. Display All Students — displays all saved records.
3. Search Student — finds a record by roll number.
4. Update Student — changes the name, course, and marks for a roll number.
5. Delete Student — removes a record by roll number.
0. Exit — closes the program.

## C concepts used
- Structure (`struct Student`)
- Functions
- `if`, `switch`, and loops
- Arrays and strings
- File handling (`fopen`, `fread`, `fwrite`, `fclose`)
- Header files and constants

## GitHub upload
1. Sign in to GitHub and create a new repository.
2. Give it the name `Student-Record-Management-System`.
3. Choose **Add file → Upload files**.
4. Upload `student_record.c` and `README.md` from this folder.
5. Press **Commit changes**.

Do not upload personal student information. The `students.dat` file is created
when the program runs; it is not needed to submit the source code.

## Presentation outline
- Introduce the project and its purpose.
- Explain the menu and each operation.
- Demonstrate adding, displaying, searching, updating, and deleting a sample record.
- Explain the structure and file handling used in the program.
